import { useContext } from "react";
import appContext from "../context/globalContext";

const { useNavigate } = require("react-router-dom");

const Portfolio = () => {
    let context=useContext(appContext)
    let navigate=useNavigate()
    const logout = () => {
        context.setToken("");
        localStorage.clear();
      };
    return (
        <section class="mai___accc Portfolio_page">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-8 col-sm-12">
                        <div class="main_account_apc">
                            <div class="inner_main__content">
                                <div class="main__acc_row">
                                    <div class="icon_mains">
                                        <div class="portfolio_hd">
                                            <h5>Portfolio</h5>
                                        </div>
                                    </div>
                                    <div class="acc_icons">
                                        <i class="fas fa-plus"></i>
                                        <img src={require('../assets/images/overview.png')}/>
                                    </div>
                                </div>
                                <div class="Main_inner">
                                    <div class="portfolio_eye">
                                        <h3>Total Balance <i class="far fa-eye"></i></h3>
                                        <p>17 accounts / 23 assests</p>
                                    </div>
                                    <div class="">
                                        <i class="fas fa-copy"></i>
                                    </div>
                                </div>
                                <div class="Main_inner__btm">
                                    <div class="balance_portfolio">
                                        <h3>$ 0.00</h3>
                                    </div>
                                </div>
                                <div class="row portfolio_row align-items-center">
                                    <div class="col-lg-6 col-md-6 col-6">
                                        <h5 class="first">Search Tokens</h5>

                                    </div>
                                    <div class="col-lg-6 col-md-6 col-6 col__end">
                                        <h5><i class="fas fa-plus"></i> Tokens</h5>
                                    </div>
                                </div>
                                <div class="over_view_tabsss tabs_All">
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button
                                                class="nav-link active"
                                                id="home-tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#home"
                                                type="button"
                                                role="tab"
                                                aria-controls="home"
                                                aria-selected="true"
                                            >
                                                Tokens
                                            </button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button
                                                class="nav-link"
                                                id="profile-tab"
                                                data-bs-toggle="tab"
                                                data-bs-target="#profile"
                                                type="button"
                                                role="tab"
                                                aria-controls="profile"
                                                aria-selected="false"
                                            >
                                                NFTs
                                            </button>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active cards cards--11" id="home" role="tabpanel" aria-labelledby="home-tab">
                                            <a class="card-coin" href="details.html">
                                                <div class="card-coin__logo"><img src={require("../assets/images/bitcoin.png")} /><span>Bitcoin <b>BTC</b></span></div>
                                                <div class="card-coin__chart"><canvas class="chartup" width="50" height="30"></canvas></div>
                                                <div class="card-coin__price"><strong>$41,827.71</strong><span class="plus">+10%</span></div>
                                            </a>
                                        </div>
                                        <div
                                            class="tab-pane fade"
                                            id="profile"
                                            role="tabpanel"
                                            aria-labelledby="profile-tab"
                                        >
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th>Tx Hash</th>
                                                        <th>Type</th>
                                                        {/* <th>From</th>
                                                                      <th>To</th> */}
                                                        <th>Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {/* {contractData.map(contract => (

                                                        <tr key={contract.txID}>
                                                            <td>{contract.txID}</td>
                                                            <td>{contract.type}</td>
                                                            
                                                            <td>{Number(contract.amount) / 1000000}</td>
                                                        </tr>
                                                    ))} */}
                                                    <tr>
                                                        <td>hiii</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="btm_main">
                    <div class="transations__tbs">
                      <div class="col">
                        <div class="trans_tabs">
                          <img src={require("../assets/images/portfolio.png")} />
                          <p>Portfolio</p>
                        </div>
                      </div>
                      <div class="col" style={{ cursor: "pointer" }} onClick={() => {
                        // if (selectedTokenName == undefined || selectedTokenName == "") {
                        //   toast.info("please select a token")
                        //   return;
                        // }
                        // let data = {
                        //   address: selectedTokenAddress ? selectedTokenAddress : "0Tx000",
                        //   balance: balance,
                        //   tokenName: selectedTokenName ? selectedTokenName : "TRX"
                        // }
                        navigate('/send', { state: '' })
                      }
                      }>

                        <div class="trans_tabs">
                          <img src={require("../assets/images/transfer.png")} />
                          <p>Transfer</p>
                        </div>
                      </div> 
                      <div class="col  active-tab">
                        <div class="trans_tabs">
                          <img src={require("../assets/images/overview.png")} />
                          <p>Overview</p>
                        </div>
                      </div>
                      <div
                        class="col"
                        style={{ cursor: "pointer" }}
                        onClick={() => navigate("/add-token")}
                      >
                        <div class="trans_tabs">
                          <img src={require("../assets/images/add-coin.png")} />
                          <p>Add Token</p>
                        </div>
                      </div>
                      <div
                        class="col"
                        style={{ cursor: "pointer" }}
                        onClick={logout}
                      >
                        <div class="trans_tabs">
                          <img src={require("../assets/images/send.png")} />
                          <p>Sign Out</p>
                        </div>
                      </div>
                    </div>
                  </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Portfolio;