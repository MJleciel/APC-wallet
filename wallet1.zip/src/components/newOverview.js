const NewOverView = () => {
    return (
        <>
            <section class="mai___accc sidebar-width">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <div class="main_account_apc">
                                <div class="inner_main__content">
                                    <div class="ETH__node">
                                        <img src={require("../assets/images/eth.png")}/>
                                            <div class="eth_flex">
                                                <h6>ETH nodes</h6>
                                                <p>We're experiencing an issue with our ETH nodes being out of syc. Reset assured, Our team is working diligently to resync them ASAP!</p>
                                            </div>
                                    </div>
                                    <div class="main__acc_row">
                                        <div class="icon_mains">
                                            <img src={require("../assets/images/aarohi-coin.png")}/>
                                                <div class="apc__coin_cntr">
                                                    <p>Select Crypto</p>
                                                    <h6>BCH</h6>
                                                    <h5>=$50.90</h5>
                                                </div>
                                        </div>
                                        <div class="acc_icons">
                                            <div class="grater-icon"></div>
                                            <i class="fas fa-plus"></i>
                                        </div>
                                    </div>
                                    <div class="Main_inner">
                                        <div class="">
                                            <h3>APC - Main Account</h3>
                                            <p>hfrjhfjhfjhfjhk</p>
                                        </div>
                                        <div class="">
                                            <i class="fas fa-copy"></i>
                                        </div>
                                    </div>
                                    <div class="Main_inner__btm">
                                        <div class="">
                                            <h3>0.00</h3>
                                            <p>-0.00 USB</p>
                                        </div>
                                    </div>
                                    <div class="row availabel-row">
                                        <div class="col-lg-6 col-md-6 col-6">
                                            <h5>Available</h5>
                                            <p>0.00</p>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-6 col__end">
                                            <h5>Unconfirmed</h5>
                                            <p>0.00</p>
                                        </div>
                                    </div>
                                    <div class="small_tabs row">
                                        <div class="col-lg-3 col-md-3 col-3">
                                            <div class="inner_tabs">
                                                <i class="far fa-paper-plane"></i>
                                                <p>Send</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-3">
                                            <div class="inner_tabs">
                                                <img src={require("../assets/images/recieve.png")}/>
                                                    <p>Recieve</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-3">
                                            <div class="inner_tabs">
                                                <img src={require("../assets/images/charge.png")}/>
                                                    <p>Charge</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-3">
                                            <div class="inner_tabs">
                                                <img src={require("../assets/images/scan.png")}/>
                                                    <p>Scan</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="btm_main">
                                    <h5>Transactions</h5>
                                    <div class="transations__tbs">
                                        <div class="col-lg-3 col-md-3 col-3">
                                            <div class="trans_tabs">
                                                <img src={require("../assets/images/overview.png")}/>
                                                    <p>Overview</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-3">
                                            <div class="trans_tabs">
                                                <img src={require("../assets/images/transfer.png")}/>
                                                    <p>Transfer</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-3">
                                            <div class="trans_tabs">
                                                <img src={require("../assets/images/add-coin.png")}/>
                                                    <p>Add Token</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-3">
                                            <div class="trans_tabs">
                                                <img src={require("../assets/images/send.png")}/>
                                                    <p>Sign Out</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default NewOverView;